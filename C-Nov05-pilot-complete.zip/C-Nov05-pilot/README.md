# Member C: November 5 Pilot Package

- Name: Yifan Shao
- Student ID: 1240027211
- Role: C
- Source repository: https://github.com/yifanshao40-a11y/cs340-period-replication
- Source commit: c6eebe0588ed8cc1dfb9a715b11f326e43b40d06
- Current status: all three original PERIOD pilots completed in session launch-3067-20011. All target assertions were confirmed. See C-Nov05-pilot-report.md and the preserved real results.

## Purpose

Run one PERIOD pilot for each original program: `reorder_3_bad`, `reorder_4_bad`, and `reorder_5_bad`. These are the three programs assigned to member C for the November 5 internal milestone. This package does not replace the later repeated experiments or the six-thread/eight-thread extension.

## Run on this Windows computer

1. Open Docker Desktop and wait for **Engine running**. Signing in is not required.
2. Double-click `START-C-PILOT.cmd` in this folder. Do not move this file away from the other package files.
3. Keep its window open. The first launch downloads `wcventure/period:stable`, resolves its digest, and runs all three programs sequentially. Do not start another copy in parallel.
4. Read the final message. The per-program time limit is 30 minutes, separate from the five-second timeout for an individual tested schedule. A timeout is an incomplete pilot; preserve its logs.
5. Inspect `results/C/launch-*/summary.md` and `summary.json`. Preserve the corresponding `results/launch-*` Docker metadata directory.

No separate LLVM, Python, or WSL Linux-distribution download is required by this launcher. Docker manages its Linux environment. The image provides the original prebuilt toolchain. The launcher only mounts the three benchmark inputs over a separate read-only path; it does not replace the image's toolchain with an incomplete Windows clone.

## Fixed pilot settings

| Setting | Value |
|---|---|
| Method | PERIOD |
| Programs | Original reorder_3_bad, reorder_4_bad, reorder_5_bad |
| Repetitions | One pilot per program |
| Bug depth | 3 |
| Schedule budget | 10,000 |
| Timeout for one tested execution | 5 seconds |
| Whole-program testing time limit | 1,800 seconds |
| Execution order | 3, then 4, then 5 |
| Serial | Not run; provenance and execution procedure remain unverified |

The exact engine command is `python3 -u /workdir/PERIOD/tool/DBDS/run_PDS.py -y -d 3 -f 10000 -t 5 ./reorder_N_bad`. The `-f` option controls the schedule budget, not repetitions. A bounded pilot does not establish exhaustive coverage.

## Completion checks

The parser requires successful compilation, engine start/end records, actual explored-schedule records, nonzero key points, the expected worker-thread count, and no detected engine/infrastructure error. An exit status of zero alone is insufficient. The original scheduler can catch exceptions and continue.

Target-bug confirmation is reported separately. It requires a saved controlled-schedule error diagnostic containing the original `checkThread` assertion. A message from a dry/default execution alone is insufficient. `Last New Find` is not reported as the first target-bug round.

If the three pilots complete but the target assertion is not confirmed, record the observed result and investigate; do not claim successful target-bug reproduction. If an infrastructure failure occurs, it is not a valid non-detection run.

## Files and handoff

- `START-C-PILOT.cmd`: Windows launcher for this installed Docker Desktop.
- `run_c_pilot.sh`: Linux pilot runner; executed inside the author's image.
- `summarize_c_pilot.py`: standard-library log parser; automatically run after testing.
- `source-CS/`: byte-preserving copies of the three checked-out benchmark input directories.
- `source-manifest.csv`: source-input SHA-256 provenance.
- `UPSTREAM-LICENSE`: the original project's license.
- `results/C/<session>/`: raw build/run logs, exact commands, environment, source hashes, diagnostics, and machine-readable summaries.
- `results/<session>/`: Docker version, image inspection and digest, launcher exit information.

The stopped container is retained for diagnosis. It uses the same SYS_NICE capability and unconfined seccomp setting supplied in the group's startup script. These settings are not proof that real-time scheduling works; actual `sched_setattr error` diagnostics invalidate a pilot.

Submit the scripts, instructions, source manifest, and genuine result directories to the group repository after inspection. The original project ignores `*.log` and `out_*`; retain the supplied local ignore exceptions and verify that the required evidence is visible before committing. The completed package includes real pilot evidence. Formal repeated experiments and the six-thread/eight-thread extension remain pending.

Use a commit message such as:

`1240027211 Yifan Shao: add C original-benchmark pilot results`

Record the actual upload time separately from the November 5 internal completion deadline. The course's weekly submission deadline is Sunday at 23:59; preserve the course's applicable time zone. Do not backdate commits.

## Scope and assistance

This package was prepared with GPT assistance for source inspection, automation, documentation, and parser review. Temporary synthetic fixtures were used only to test the parser and are not experimental evidence. All experimental claims must come from the preserved real run logs.

References: [authors' repository](https://github.com/wcventure/PERIOD), [group repository](https://github.com/yifanshao40-a11y/cs340-period-replication), and [Docker Windows installation documentation](https://docs.docker.com/desktop/setup/install/windows-install/).
