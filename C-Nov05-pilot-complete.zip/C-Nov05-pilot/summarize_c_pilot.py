#!/usr/bin/env python3
"""Parse C pilot sessions. Usage: python summarize_c_pilot.py SESSION_DIRECTORY.

Writes summary.json, summary.csv and summary.md. Standard library, Python 3.6+.
"""
import argparse
import csv
import json
import re
from pathlib import Path

ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")

# Exact runtime diagnostics from tool/DBDS/run_PDS.py, DBDSFunction.cpp,
# llvm-mode/sched.h and the three original reorder_N_bad.c sources.
INFRASTRUCTURE_PATTERNS = [
    ("sched_deadline_setup_failed", re.compile(r"\bsched_setattr error\b")),
    ("shared_memory_id_failed", re.compile(r"Error: getting shared memory id\. 1")),
    ("shared_memory_attach_failed", re.compile(r"Error: attaching shared memory id\. 2")),
    ("thread_creation_failed", re.compile(r"Error \[\d+\] found creating (?:set|check) thread\.")),
    ("thread_join_failed", re.compile(r"pthread join error: -?\d+")),
    ("command_not_found", re.compile(r": command not found")),
    ("multithread_detection_failed", re.compile(r"Can not catch multithread mode")),
    ("default_schedule_failed", re.compile(r"There seems to be some errors when executing the default schedule\.")),
]


def infrastructure_diagnostics(text, evidence_path):
    return [{"kind": kind, "evidence_path": evidence_path}
            for kind, pattern in INFRASTRUCTURE_PATTERNS if pattern.search(text)]


def read_text(path):
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except FileNotFoundError:
        return ""


def env_values(path):
    return dict(line.split("=", 1) for line in read_text(path).splitlines()
                if "=" in line and not line.startswith("#"))


def last_int(pattern, text):
    matches = re.findall(pattern, text, flags=re.MULTILINE)
    return int(matches[-1]) if matches else None


def parse_case(session, name):
    folder = session / name
    metadata = env_values(folder / "status.env")
    text = ANSI.sub("", read_text(folder / "run.log"))
    engine_exception_count = len(re.findall(r"^\s*Unknown Exception\s*$", text, re.MULTILINE))
    infrastructure = infrastructure_diagnostics(text, str((folder / "run.log").relative_to(session)))
    summary_rounds = last_int(r"^Round\s+\d+\s+(\d+)\s*$", text)
    last_new_find = last_int(r"^Round\s+(\d+)\s+\d+\s*$", text)
    # Engine can print a cap+1 label before checking its limit. Require a schedule.
    labels = re.findall(r"\btest\s+(\d+)(?:\s+for prefix [^\r\n]+)?:\s*\[", text)
    executed_labels = [int(label) for label in labels]
    started = "Start Testing!" in text
    ended = "End Testing!" in text
    run_rc = metadata.get("run_exit_code")
    build_ok = metadata.get("build_exit_code") == "0"
    completed = (build_ok and run_rc == "0" and started and ended and
                 summary_rounds is not None and summary_rounds > 0 and bool(executed_labels))
    threads = last_int(r"^ThreadNum:\s*(\d+)", text)
    max_kp = last_int(r"^MaxKpNum:\s*(\d+)", text)
    # Original defaults create N-1 setter threads plus one checker. The main
    # thread is excluded by the instrumentation's traceEnd() thread counter.
    expected_threads = {"reorder_3": 3, "reorder_4": 4, "reorder_5": 5}[name]
    thread_count_matches = threads == expected_threads
    completed = completed and thread_count_matches and max_kp is not None and max_kp > 0
    diagnostic_files = []
    target_files = []
    artifact_dir = folder / "artifacts"
    if artifact_dir.exists():
        for candidate in sorted(artifact_dir.rglob("*")):
            if not candidate.is_file() or "Errors" not in candidate.parts:
                continue
            diagnostic_files.append(str(candidate.relative_to(session)))
            diagnostic = ANSI.sub("", read_text(candidate))
            infrastructure.extend(infrastructure_diagnostics(
                diagnostic, str(candidate.relative_to(session))))
            # Actual error diagnostics count; source/build-log assertions do not.
            target_assertion = ("checkThread" in diagnostic and
                                re.search(r"Assertion\s+[`'\u2018\u2019]?0[`'\u2018\u2019]?\s+failed", diagnostic))
            if target_assertion:
                target_files.append(str(candidate.relative_to(session)))
    errors = last_int(r"^Total Error Interleavings:\s*(\d+)", text)
    timeouts = last_int(r"^Total Timeouts Interleavings:\s*(\d+)", text)
    cap = int(env_values(session / "session.env").get("schedule_cap", "10000"))
    cap_reached = summary_rounds is not None and summary_rounds > cap
    completed = bool(completed and engine_exception_count == 0 and not infrastructure)
    if not folder.exists():
        status = "not_run"
    elif not build_ok:
        status = "build_failed_or_not_completed"
    elif run_rc in ("124", "137"):
        status = "outer_timeout_incomplete"
    elif infrastructure:
        status = "infrastructure_failed"
    elif engine_exception_count:
        status = "engine_exception_incomplete"
    elif not thread_count_matches:
        status = "thread_count_mismatch" if threads is not None else "run_failed_or_incomplete"
    elif not completed:
        status = "run_failed_or_incomplete"
    else:
        status = "complete_bounded_pilot" if cap_reached else "complete_pilot"
    return {
        "benchmark": name, "method": "PERIOD", "repetition": 1,
        "status": status, "pilot_complete": bool(completed),
        "target_assertion_reproduced": bool(target_files),
        "build_exit_code": metadata.get("build_exit_code"), "run_exit_code": run_rc,
        "thread_count_reported": threads, "max_key_points_reported": max_kp,
        "expected_thread_count": expected_threads,
        "thread_count_matches_expected": thread_count_matches,
        "engine_exception_count": engine_exception_count,
        "infrastructure_error_count": len(infrastructure),
        "infrastructure_diagnostics": infrastructure,
        "start_testing_seen": started, "end_testing_seen": ended,
        "engine_reported_rounds": summary_rounds,
        "executed_schedule_labels": len(executed_labels),
        "maximum_executed_schedule_label": max(executed_labels) if executed_labels else None,
        "schedule_cap_reached": cap_reached,
        "total_error_interleavings": errors, "total_timeout_interleavings": timeouts,
        "last_new_find_round_not_first_bug": last_new_find,
        "first_target_bug_round": None,
        "error_artifact_files": diagnostic_files, "target_assertion_artifacts": target_files,
        "serial_status": "not_run_unverified",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("session", type=Path)
    args = parser.parse_args()
    if not (args.session / "session.env").is_file():
        parser.error("Expected a session directory containing session.env")
    cases = [parse_case(args.session, "reorder_{}".format(n)) for n in (3, 4, 5)]
    report = {
        "session": env_values(args.session / "session.env"),
        "all_three_pilots_complete": all(case["pilot_complete"] for case in cases),
        "all_three_target_assertions_reproduced": all(case["target_assertion_reproduced"] for case in cases),
        "cases": cases,
        "notes": [
            "This is one pilot per program, not a repeated formal replication.",
            "Complete pilot and confirmed target assertion are separate conditions.",
            "Unknown engine exceptions, source-backed infrastructure diagnostics, or unexpected thread counts invalidate completion.",
            "Infrastructure evidence paths refer to retained raw logs/artifacts; raw evidence is never edited by this parser.",
            "Serial has not been run or verified.",
            "Last New Find is not the first target bug round; the latter remains null.",
            "A capped run may report cap+1 rounds because the engine increments before checking the cap.",
            "Assertions in dry/default runs alone are not controlled-schedule artifact evidence.",
        ],
    }
    (args.session / "summary.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    fields = [key for key in cases[0] if key not in ("error_artifact_files", "target_assertion_artifacts", "infrastructure_diagnostics")]
    with (args.session / "summary.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(cases)
    lines = ["# C pilot summary", "", "One PERIOD pilot per original benchmark. Serial: not run/unverified.", "",
             "| Program | Status | Controlled target assertion | Reported rounds | Errors | Timeouts |",
             "|---|---|---|---:|---:|---:|"]
    for case in cases:
        lines.append("| {benchmark} | {status} | {target} | {rounds} | {errors} | {timeouts} |".format(
            target="confirmed" if case["target_assertion_reproduced"] else "not confirmed",
            rounds=case["engine_reported_rounds"], errors=case["total_error_interleavings"],
            timeouts=case["total_timeout_interleavings"], **case))
    lines += ["", "Raw evidence and source provenance are retained in each program directory.", "",
              "Last New Find is not a first-bug metric. A schedule cap is a bounded pilot, not exhaustive exploration.", ""]
    (args.session / "summary.md").write_text("\n".join(lines), encoding="utf-8")
    print("Saved summary.json, summary.csv and summary.md to {}".format(args.session))
    for case in cases:
        print("{}: {}; target assertion {}".format(case["benchmark"], case["status"],
              "confirmed" if case["target_assertion_reproduced"] else "not confirmed"))
    return 0 if report["all_three_pilots_complete"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
