#!/usr/bin/env bash
# Run in the author's Linux Docker image; mount inputs read-only at /input/CS.
set -uo pipefail
umask 022
export ROOT_DIR=/workdir/PERIOD
export PATH="$ROOT_DIR/clang+llvm/bin:$ROOT_DIR/tool/SVF/Release-build/bin:$PATH"
export LD_LIBRARY_PATH="$ROOT_DIR/clang+llvm/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
SOURCE_CS=${C_SOURCE_CS_DIR:-/input/CS}
RESULTS_BASE=${C_RESULTS_DIR:-/results/C}
WALL_TIMEOUT=${C_WALL_TIMEOUT_SECONDS:-1800}
SESSION_ID=${C_SESSION_ID:-$(date -u +%Y%m%dT%H%M%SZ)-$$}
case "$SESSION_ID" in *[!A-Za-z0-9_.-]*|'') echo 'Invalid C_SESSION_ID' >&2; exit 2;; esac
case "$WALL_TIMEOUT" in *[!0-9]*|'') echo 'Invalid C_WALL_TIMEOUT_SECONDS' >&2; exit 2;; esac
SESSION="$RESULTS_BASE/$SESSION_ID"
if [ ! -d "$SOURCE_CS" ] || [ ! -x "$ROOT_DIR/clang+llvm/bin/clang" ] || [ ! -f "$ROOT_DIR/tool/DBDS/run_PDS.py" ]; then
    echo 'Missing /input/CS or the official /workdir/PERIOD toolchain.' >&2
    exit 2
fi
if [ "$(readlink -f "$SOURCE_CS")" = "$(readlink -f "$ROOT_DIR/evaluation/CS")" ]; then
    echo 'Mount input separately from image-local staging.' >&2
    exit 2
fi
for utility in python3 tee sha256sum timeout flock; do
    command -v "$utility" >/dev/null || { echo "Missing utility: $utility" >&2; exit 2; }
done
if [ -e "$SESSION" ]; then echo "Refusing to overwrite $SESSION" >&2; exit 2; fi
mkdir -p "$SESSION" || exit 2
exec 9>/tmp/period-c-pilot.lock
flock -n 9 || { echo 'Another C pilot is running in this container.' >&2; exit 2; }
{
    printf 'session_id=%s\nsource_commit=%s\nimage_reference=%s\n' "$SESSION_ID" "${C_SOURCE_COMMIT:-unknown}" "${C_IMAGE_REFERENCE:-unknown}"
    printf 'source_cs_dir=%s\nroot_dir=%s\nserial_status=not_run_unverified\n' "$SOURCE_CS" "$ROOT_DIR"
    printf 'pilot_repetitions=1\nbug_depth=3\nschedule_cap=10000\nsubprocess_timeout_seconds=5\n'
    printf 'whole_run_timeout_seconds=%s\nstarted_utc=%s\n' "$WALL_TIMEOUT" "$(date -u +%FT%TZ)"
} > "$SESSION/session.env"
{
    date -u +%FT%TZ
    uname -a
    [ ! -f /etc/os-release ] || cat /etc/os-release
    command -v lscpu >/dev/null && lscpu
    printf '\n--- Selected environment (no credentials) ---\n'
    printf 'ROOT_DIR=%s\nPATH=%s\nLD_LIBRARY_PATH=%s\n' "$ROOT_DIR" "$PATH" "$LD_LIBRARY_PATH"
    printf '\n--- Tool versions and hashes ---\n'
    command -v clang clang++ python3
    clang --version
    python3 --version
    sha256sum "$ROOT_DIR/tool/DBDS/run_PDS.py" "$ROOT_DIR/tool/staticAnalysis/staticAnalysis.sh" "$ROOT_DIR/tool/staticAnalysis/DBDS-INSTRU/dbds-clang-fast++" "$ROOT_DIR/tool/staticAnalysis/DBDS-INSTRU/DBDSFunction.o"
} > "$SESSION/environment.log" 2>&1
for n in 3 4 5; do
    bench="reorder_${n}"
    input="$SOURCE_CS/$bench"
    stage="$ROOT_DIR/evaluation/CS/$bench"
    result="$SESSION/$bench"
    mkdir -p "$result/source" "$result/artifacts" || exit 2
    printf 'benchmark=%s\nmethod=PERIOD\nrepetition=1\nstarted_utc=%s\n' "$bench" "$(date -u +%FT%TZ)" > "$result/status.env"
    if [ ! -f "$input/build.sh" ] || [ ! -f "$input/cleanDIR.sh" ] || [ ! -f "$input/${bench}_bad.c" ]; then
        echo 'input_error=missing original benchmark files' >> "$result/status.env"
        continue
    fi
    mkdir -p "$stage" || exit 2
    # Keep preexisting image output separate from this pilot's evidence.
    for old_output in "$stage"/out_*; do
        [ ! -e "$old_output" ] || {
            mkdir -p "$result/preexisting_not_this_pilot"
            mv "$old_output" "$result/preexisting_not_this_pilot/" || exit 2
        }
    done
    for filename in build.sh cleanDIR.sh "${bench}_bad.c" README.md; do
        [ ! -f "$input/$filename" ] || cp -p "$input/$filename" "$result/source/$filename" || exit 2
        [ ! -f "$input/$filename" ] || cp -p "$input/$filename" "$stage/$filename" || exit 2
    done
    (cd "$result/source" && sha256sum *) > "$result/source_sha256.txt"
    # Only image-local staged shell scripts are normalized.
    sed -i 's/\r$//' "$stage/build.sh" "$stage/cleanDIR.sh"
    chmod +x "$stage/build.sh" "$stage/cleanDIR.sh"
    (cd "$stage" && sha256sum build.sh cleanDIR.sh "${bench}_bad.c") > "$result/staged_sha256.txt"
    printf 'cd %q\nbash ./build.sh\n' "$stage" > "$result/build.command.sh"
    (cd "$stage" && bash ./build.sh) 2>&1 | tee "$result/build.log"
    build_codes=("${PIPESTATUS[@]}")
    build_rc=${build_codes[0]}
    printf 'build_log_exit_code=%s\n' "${build_codes[1]}" >> "$result/status.env"
    if [ "${build_codes[1]}" -ne 0 ]; then build_rc=125; fi
    printf 'build_exit_code=%s\n' "$build_rc" >> "$result/status.env"
    if [ "$build_rc" -eq 0 ] && [ -x "$stage/${bench}_bad" ]; then
        command_args=(python3 -u "$ROOT_DIR/tool/DBDS/run_PDS.py" -y -d 3 -f 10000 -t 5 "./${bench}_bad")
        printf 'cd %q\n' "$stage" > "$result/run.command.sh"
        printf '%q ' "${command_args[@]}" >> "$result/run.command.sh"
        printf '\n' >> "$result/run.command.sh"
        if [ "$WALL_TIMEOUT" -gt 0 ]; then
            (cd "$stage" && timeout --signal=TERM --kill-after=10 "$WALL_TIMEOUT" "${command_args[@]}") 2>&1 | tee "$result/run.log"
        else
            (cd "$stage" && "${command_args[@]}") 2>&1 | tee "$result/run.log"
        fi
        run_codes=("${PIPESTATUS[@]}")
        run_rc=${run_codes[0]}
        printf 'run_log_exit_code=%s\n' "${run_codes[1]}" >> "$result/status.env"
        if [ "${run_codes[1]}" -ne 0 ]; then run_rc=125; fi
        printf 'run_exit_code=%s\n' "$run_rc" >> "$result/status.env"
    else
        run_rc=125
        printf 'run_skipped=build_failed_or_binary_missing\n' >> "$result/status.env"
    fi
    for generated in "$stage"/out_*; do
        [ ! -e "$generated" ] || cp -a "$generated" "$result/artifacts/" || exit 2
    done
    for generated in "$stage"/ConConfig.* "$stage"/mssa.* "$stage"/so.* "$stage"/mempair.* "$stage"/dryRun.* "$stage"/dbds.*; do
        [ ! -f "$generated" ] || cp -p "$generated" "$result/artifacts/" || exit 2
    done
    printf 'finished_utc=%s\n' "$(date -u +%FT%TZ)" >> "$result/status.env"
    if [ "$run_rc" -eq 124 ] || [ "$run_rc" -eq 137 ]; then
        echo "Stopped after outer timeout for $bench; use a fresh container next." >&2
        echo 'session_stop_reason=whole_run_timeout_restart_container_required' >> "$SESSION/session.env"
        break
    fi
done
printf 'finished_utc=%s\n' "$(date -u +%FT%TZ)" >> "$SESSION/session.env"
SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
if [ -f "$SCRIPT_DIR/summarize_c_pilot.py" ]; then
    python3 "$SCRIPT_DIR/summarize_c_pilot.py" "$SESSION"
    exit $?
fi
echo "Raw evidence saved at $SESSION; run summarize_c_pilot.py to validate."
