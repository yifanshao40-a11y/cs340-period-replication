@echo off
setlocal EnableExtensions DisableDelayedExpansion
title PERIOD C - three original pilot experiments
set "BUNDLE=%~dp0"
set "BUNDLE=%BUNDLE:~0,-1%"
cd /d "%BUNDLE%"
set "DOCKER=C:\Users\Lenovo\AppData\Local\Programs\DockerDesktop\resources\bin\docker.exe"
if not exist "%DOCKER%" set "DOCKER=C:\Program Files\Docker\Docker\resources\bin\docker.exe"
if not exist "%DOCKER%" goto docker_missing
set "RUN_ID=launch-%RANDOM%-%RANDOM%"
set "HOST_LOGS=%BUNDLE%\results\%RUN_ID%"
if exist "%HOST_LOGS%" goto collision
mkdir "%HOST_LOGS%"
if errorlevel 1 goto setup_failed
"%DOCKER%" --context desktop-linux version > "%HOST_LOGS%\docker-version.txt" 2>&1
if errorlevel 1 goto docker_unavailable
> "%HOST_LOGS%\launcher.env" echo source_commit=c6eebe0588ed8cc1dfb9a715b11f326e43b40d06
echo Pulling the authors' PERIOD image. This may take several minutes.
"%DOCKER%" --context desktop-linux pull wcventure/period:stable
if errorlevel 1 goto pull_failed
"%DOCKER%" --context desktop-linux image inspect wcventure/period:stable > "%HOST_LOGS%\image-inspect.json" 2>&1
if errorlevel 1 goto setup_failed
"%DOCKER%" --context desktop-linux image inspect --format "{{index .RepoDigests 0}}" wcventure/period:stable > "%HOST_LOGS%\image-reference.txt"
if errorlevel 1 goto setup_failed
set "IMAGE_REFERENCE="
set /p "IMAGE_REFERENCE=" < "%HOST_LOGS%\image-reference.txt"
if not defined IMAGE_REFERENCE goto setup_failed
echo Running reorder_3, reorder_4, and reorder_5 sequentially.
echo Keep this window open. Raw logs appear under the results folder.
echo One pilot can take up to 30 minutes per program.
"%DOCKER%" --context desktop-linux run --name "period-c-%RUN_ID%" --cap-add=SYS_NICE --security-opt seccomp=unconfined --workdir /workdir/PERIOD --env "C_SOURCE_COMMIT=c6eebe0588ed8cc1dfb9a715b11f326e43b40d06" --env "C_IMAGE_REFERENCE=%IMAGE_REFERENCE%" --env "C_SESSION_ID=%RUN_ID%" --env "C_RESULTS_DIR=/results/C" --mount "type=bind,source=%BUNDLE%\source-CS,target=/input/CS,readonly" --mount "type=bind,source=%BUNDLE%,target=/pilot,readonly" --mount "type=bind,source=%BUNDLE%\results,target=/results" "%IMAGE_REFERENCE%" bash -c "bash -n /pilot/run_c_pilot.sh && bash /pilot/run_c_pilot.sh"
set "PILOT_EXIT=%ERRORLEVEL%"
>> "%HOST_LOGS%\launcher.env" echo pilot_exit_code=%PILOT_EXIT%
>> "%HOST_LOGS%\launcher.env" echo container_name=period-c-%RUN_ID%
if not "%PILOT_EXIT%"=="0" goto pilot_incomplete
echo All three bounded pilots passed the parser's completion checks.
echo Target-bug confirmation is reported separately in summary.md.
goto finished
:docker_missing
echo Docker Desktop was not found. Ask for help before continuing.
goto failed
:docker_unavailable
type "%HOST_LOGS%\docker-version.txt"
echo Start Docker Desktop and wait for Engine running, then retry.
goto failed
:pull_failed
echo Image download failed. Preserve the displayed error and ask for help.
goto failed
:collision
echo Session directory already exists. No existing data was changed.
goto failed
:setup_failed
echo Preparation failed. Preserve the displayed error and ask for help.
goto failed
:pilot_incomplete
echo At least one pilot is incomplete. Do not claim the Nov 5 milestone is done.
echo Leave all logs intact for diagnosis.
goto finished
:failed
pause
exit /b 1
:finished
echo Results folder: %BUNDLE%\results
echo The stopped container is retained for diagnosis; existing results are preserved.
pause
exit /b %PILOT_EXIT%