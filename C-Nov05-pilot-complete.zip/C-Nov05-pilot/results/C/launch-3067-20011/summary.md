# C pilot summary

One PERIOD pilot per original benchmark. Serial: not run/unverified.

| Program | Status | Controlled target assertion | Reported rounds | Errors | Timeouts |
|---|---|---|---:|---:|---:|
| reorder_3 | complete_pilot | confirmed | 27 | 6 | 0 |
| reorder_4 | complete_pilot | confirmed | 100 | 12 | 0 |
| reorder_5 | complete_pilot | confirmed | 225 | 20 | 0 |

Raw evidence and source provenance are retained in each program directory.

Last New Find is not a first-bug metric. A schedule cap is a bounded pilot, not exhaustive exploration.
