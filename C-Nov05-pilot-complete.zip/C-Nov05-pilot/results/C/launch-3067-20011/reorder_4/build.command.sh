cd /workdir/PERIOD/evaluation/CS/reorder_4
bash ./build.sh
