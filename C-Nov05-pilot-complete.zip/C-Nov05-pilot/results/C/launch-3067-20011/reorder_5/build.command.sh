cd /workdir/PERIOD/evaluation/CS/reorder_5
bash ./build.sh
