cd /workdir/PERIOD/evaluation/CS/reorder_5
python3 -u /workdir/PERIOD/tool/DBDS/run_PDS.py -y -d 3 -f 10000 -t 5 ./reorder_5_bad 
