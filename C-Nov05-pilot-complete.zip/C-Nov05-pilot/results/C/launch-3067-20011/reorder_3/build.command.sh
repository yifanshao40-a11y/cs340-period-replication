cd /workdir/PERIOD/evaluation/CS/reorder_3
bash ./build.sh
