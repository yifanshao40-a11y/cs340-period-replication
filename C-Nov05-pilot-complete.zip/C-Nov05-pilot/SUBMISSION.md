# GitHub Submission Instructions

Owner: Yifan Shao (1240027211), member C.

## Recommended website upload: two files

Upload these two files from the parent `outputs` folder:

1. `C-Nov05-pilot-report.md`: the English report that GitHub can display directly.
2. `C-Nov05-pilot-complete.zip`: the full reproducible package, including the report, launcher, scripts, source provenance, original input copies, real logs, all saved assertion diagnostics, summaries, Docker metadata and evidence checksums.

The ZIP preserves the complete directory structure. Reviewers can download and extract it to inspect or rerun the experiment. Do not upload only the report without its evidence archive.

## Upload through the GitHub website

1. Open https://github.com/yifanshao40-a11y/cs340-period-replication and select the `main` branch.
2. Above the file list, select **Add file** then **Upload files**.
3. Select `C-Nov05-pilot-report.md` and `C-Nov05-pilot-complete.zip` from the parent `outputs` folder.
4. Confirm both filenames appear in the upload list.
5. Use this commit message:

   `1240027211 Yifan Shao: submit C original-benchmark pilot results`

6. Select the group's normal branch/commit option and click **Commit changes**.
7. Open the report in the repository and download the ZIP to confirm both files are accessible.
8. Record the actual commit URL/time as the submission record. Completion time and submission time are separate.

If the group prefers browsable raw files, it can additionally commit the expanded `C-Nov05-pilot` directory through Git. Retain the supplied local `.gitignore` exceptions because the original project ignores `*.log` and `out_*`.

No GitHub upload has been performed by the assistant. Do not change raw logs to fit an expected result. This submission covers the three original PERIOD pilots; repeated formal runs, Serial, and 6/8-worker extensions remain later work.
