# Member C Source Inspection Note

- Name: Yifan Shao
- Student ID: 1240027211
- Role: C
- Inspected revision: c6eebe0588ed8cc1dfb9a715b11f326e43b40d06
- Status: original 3/4/5-worker pilots completed; runtime validation of the proposed 6/8-worker extension remains pending.

## Original programs and thread definitions

The original `reorder_3_bad.c`, `reorder_4_bad.c`, and `reorder_5_bad.c` initialize `iSet` to 2, 3, and 4 respectively, and initialize `iCheck` to 1. Their nominal thread counts are therefore 3, 4, and 5 worker threads. The main thread is not included in these labels.

The five-thread source defines its defaults at lines 2788-2789. Its `main` reads two optional integer arguments into `iSet` and `iCheck` at lines 2809-2810. It allocates thread pools at lines 2816-2817, creates each setter and checker in loops at lines 2819-2831, and joins them at lines 2834-2847.

`setThread` writes `a = 1` and `b = -1` at lines 2852-2853. `checkThread` accepts the two consistent states `(a == 0 && b == 0)` and `(a == 1 && b == -1)`; otherwise it prints `Bug found!` and asserts zero. The original target assertion must remain the bug criterion.

## Implication for the later extension

The source supports proposed configurations with five setters plus one checker (six workers) and seven setters plus one checker (eight workers) using the five-thread binary's arguments `5 1` and `7 1`. This suggests that source edits may be unnecessary. Runtime discovery of the expected thread count, instrumentation, and target assertion still requires validation before these become accepted extension configurations.

The November 5 launcher intentionally uses the three original binaries without arguments. The extension is a later milestone. Increasing setter count also increases total work; a future runtime comparison must disclose that difference.

## Reproducibility boundaries

The original `build.sh` scripts calculate `ROOT_DIR` from their own location. Merely exporting a different root does not relocate those scripts. The pilot therefore copies inputs to the author's image-local benchmark paths and preserves the image's prebuilt toolchain at `/workdir/PERIOD`.

Only staged shell-script line endings are normalized. Both original input hashes and staged hashes are recorded when the pilot runs. The input copies in this package match the checked-out group repository byte for byte.

The source tree contains an older scheduling runner, but this inspection does not establish that it is the paper's Serial baseline. Serial remains unverified and unrun.

Source reference: [five-thread source at the inspected group revision](https://github.com/yifanshao40-a11y/cs340-period-replication/blob/c6eebe0588ed8cc1dfb9a715b11f326e43b40d06/evaluation/CS/reorder_5/reorder_5_bad.c).
